<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<body>
<div class="header bg-dark pb-3 pt-xl-5 pt-lg-5 pt-md-2 pt-sm-2">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-10 col-sm-6">
                    <h1 class="text-white">Departamentos</h1>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid pt-2">
    <div class="header-body text-center mb-7">
        <div class="row justify-content-center">
            <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="col-xl-6 col-lg-6 col-md-10 col-sm-8">
                <div class="card">
                    <div class="card-header text-bold ">
                        <strong>
                            <h2>Nuevo</h2>
                        </strong>
                    </div>
                    <form method="post" role="form" enctype="multipart/form-data" action="<?php echo e(route('department.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="card">
                            <div class="card-body bg-light">
                                <div class="form-group<?php echo e($errors->has('nombre') ? ' has-danger' : ''); ?>">
                                    <div class="form-floating mb-3">
                                        <input class="form-control <?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?> text-dark" aria-describedby="basic-addon2" placeholder="<?php echo e(__('Departamento')); ?>" id="nombre" type="text" name="nombre" value="<?php echo e(old('nombre')); ?>" required>
                                        <label for="nombre">Departamento</label>
                                    </div>
                                        
                                    <?php if($errors->has('nombre')): ?>
                                        <span class="invalid-feedback" style="display: block;" role="alert">
                                            <strong><?php echo e($errors->first('nombre')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="container">
                                    <div class="col-md-4 mb-10 center"><button type="submit" class="btn btn-outline-primary">Registrar</button></div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html><?php /**PATH C:\Users\Equipo\Documents\Universidad\Proyecto de Carrera\apiIncluSignia\resources\views/department.blade.php ENDPATH**/ ?>